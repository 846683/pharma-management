package com.cognizant.pharmaWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MainProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
